// Generated from: features/contacts.feature
import { test } from "../../../fixtures.js";

test.describe('Contacts Management Module', () => {

  test.beforeEach('Background', async ({ Given, logger, page }, testInfo) => { if (testInfo.error) return;
    await Given('the authenticated user is on the Suite8Demo home page', null, { logger, page }); 
  });
  
  test('Verify Contacts dropdown menu expands on hover', { tag: ['@contacts', '@ContactsDropdownVisible'] }, async ({ When, Then, contactsPage, logger }) => { 
    await When('the user hovers over the Contacts tab', null, { contactsPage, logger }); 
    await Then('the Contacts dropdown menu should be displayed', null, { contactsPage }); 
  });

  test('Verify Contacts module navigation', { tag: ['@contacts', '@ContactsDropdown'] }, async ({ When, Then, contactsPage, logger }) => { 
    await When('the user hovers over the Contacts module in the top navigation', null, { contactsPage, logger }); 
    await Then('the user should see the Contacts dropdown options', {"dataTable":{"rows":[{"cells":[{"value":"Create Contact"}]},{"cells":[{"value":"View Contacts"}]},{"cells":[{"value":"Import Contacts"}]},{"cells":[{"value":"Create Contact From Vcard"}]}]}}, { contactsPage, logger }); 
  });

  test('Verify that the user is redirected to the selected Contacts page', { tag: ['@contacts', '@ContactsNavigation'] }, async ({ When, Then, contactsPage, logger }) => { 
    await When('The user clicks on the <ContactsMenu> option', null, { contactsPage, logger }); 
    await Then('The user should be redirected to the <Contactspage> successfully', {"dataTable":{"rows":[{"cells":[{"value":"ContactsMenu"},{"value":"Contactspage"}]},{"cells":[{"value":"Create Contact"},{"value":"Create Contact"}]},{"cells":[{"value":"Create Contact From vCard"},{"value":"Create Contact From vCard"}]},{"cells":[{"value":"View Contacts"},{"value":"View Contacts"}]},{"cells":[{"value":"Import Contacts"},{"value":"Import Contacts"}]}]}}, { contactsPage, logger }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/contacts.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":8,"tags":["@contacts","@ContactsDropdownVisible"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"When the user hovers over the Contacts tab","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"Then the Contacts dropdown menu should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":15,"pickleLine":13,"tags":["@contacts","@ContactsDropdown"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":14,"keywordType":"Action","textWithKeyword":"When the user hovers over the Contacts module in the top navigation","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":15,"keywordType":"Outcome","textWithKeyword":"Then the user should see the Contacts dropdown options","stepMatchArguments":[]}]},
  {"pwTestLine":20,"pickleLine":22,"tags":["@contacts","@ContactsNavigation"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":23,"keywordType":"Action","textWithKeyword":"When The user clicks on the <ContactsMenu> option","stepMatchArguments":[]},{"pwStepLine":22,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"Then The user should be redirected to the <Contactspage> successfully","stepMatchArguments":[]}]},
]; // bdd-data-end
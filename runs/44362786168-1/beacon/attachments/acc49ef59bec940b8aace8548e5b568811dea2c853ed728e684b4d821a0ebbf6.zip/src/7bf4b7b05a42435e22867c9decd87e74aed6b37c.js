// Generated from: features/login.feature
import { test } from "../../../fixtures.js";

test.describe('Login to Suite8', () => {

  test.beforeEach('Background', async ({ Given, logger, loginPage }, testInfo) => { if (testInfo.error) return;
    await Given('the user is on the Suite8 login page', null, { logger, loginPage }); 
  });
  
  test('User logs in with valid credentials', { tag: ['@login', '@Positive'] }, async ({ When, Then, logger, loginPage, page }) => { 
    await When('the user enters valid login credentials', null, { logger, loginPage }); 
    await Then('the user should be logged in successfully', null, { logger, page }); 
  });

  test('Verify password is hidden when user enters password', { tag: ['@login', '@PasswordHidden'] }, async ({ When, Then, loginPage }) => { 
    await When('the user enters a password', null, { loginPage }); 
    await Then('the user should see the password displayed as hidden characters', null, { loginPage }); 
  });

  test('User cannot log in with an empty password', { tag: ['@login', '@Negative', '@EmptyPassword'] }, async ({ When, Then, logger, loginPage }) => { 
    await When('the user logs in using Excel data for scenario "empty_password"', null, { logger, loginPage }); 
    await Then('the login error message from Excel for scenario "empty_password" should be displayed', null, { logger, loginPage }); 
  });

  test('User cannot log in with an empty login', { tag: ['@login', '@Negative', '@EmptyLogin'] }, async ({ When, Then, logger, loginPage }) => { 
    await When('the user logs in using Excel data for scenario "empty_login"', null, { logger, loginPage }); 
    await Then('the login error message from Excel for scenario "empty_login" should be displayed', null, { logger, loginPage }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/login.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":8,"tags":["@login","@Positive"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the user is on the Suite8 login page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"When the user enters valid login credentials","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"Then the user should be logged in successfully","stepMatchArguments":[]}]},
  {"pwTestLine":15,"pickleLine":23,"tags":["@login","@PasswordHidden"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the user is on the Suite8 login page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":24,"keywordType":"Action","textWithKeyword":"When the user enters a password","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"Then the user should see the password displayed as hidden characters","stepMatchArguments":[]}]},
  {"pwTestLine":20,"pickleLine":28,"tags":["@login","@Negative","@EmptyPassword"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the user is on the Suite8 login page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":29,"keywordType":"Action","textWithKeyword":"When the user logs in using Excel data for scenario \"empty_password\"","stepMatchArguments":[{"group":{"start":47,"value":"\"empty_password\"","children":[{"start":48,"value":"empty_password","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":22,"gherkinStepLine":30,"keywordType":"Outcome","textWithKeyword":"Then the login error message from Excel for scenario \"empty_password\" should be displayed","stepMatchArguments":[{"group":{"start":48,"value":"\"empty_password\"","children":[{"start":49,"value":"empty_password","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":25,"pickleLine":33,"tags":["@login","@Negative","@EmptyLogin"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the user is on the Suite8 login page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":26,"gherkinStepLine":34,"keywordType":"Action","textWithKeyword":"When the user logs in using Excel data for scenario \"empty_login\"","stepMatchArguments":[{"group":{"start":47,"value":"\"empty_login\"","children":[{"start":48,"value":"empty_login","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":27,"gherkinStepLine":35,"keywordType":"Outcome","textWithKeyword":"Then the login error message from Excel for scenario \"empty_login\" should be displayed","stepMatchArguments":[{"group":{"start":48,"value":"\"empty_login\"","children":[{"start":49,"value":"empty_login","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end
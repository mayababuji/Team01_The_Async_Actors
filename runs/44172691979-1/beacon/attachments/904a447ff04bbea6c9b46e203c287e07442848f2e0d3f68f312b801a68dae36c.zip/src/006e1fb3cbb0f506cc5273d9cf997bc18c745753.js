// Generated from: features/leads.feature
import { test } from "../../../fixtures.js";

test.describe('Leads management', () => {

  test.beforeEach('Background', async ({ Given, logger, page }, testInfo) => { if (testInfo.error) return;
    await Given('the authenticated user is on the Suite8Demo home page', null, { logger, page }); 
  });
  
  test('Verify the Leads navigation menu options', { tag: ['@leads', '@authenticated', '@leadsdropdown'] }, async ({ When, Then, leadsPage }) => { 
    await When('the user hovers over the Leads navigation menu', null, { leadsPage }); 
    await Then('the Leads dropdown should display the following options:', {"dataTable":{"rows":[{"cells":[{"value":"option"}]},{"cells":[{"value":"Create Lead"}]},{"cells":[{"value":"Create Lead From vCard"}]},{"cells":[{"value":"View Leads"}]},{"cells":[{"value":"Import Leads"}]}]}}, { leadsPage }); 
  });

  test('Verify the Create Lead page controls and sections', { tag: ['@leads', '@authenticated', '@createlead'] }, async ({ When, Then, leadsPage }) => { 
    await When('the user opens the Create Lead page', null, { leadsPage }); 
    await Then('the Create Lead page should display the following elements:', {"dataTable":{"rows":[{"cells":[{"value":"element"}]},{"cells":[{"value":"OVERVIEW"}]},{"cells":[{"value":"MORE INFORMATION"}]},{"cells":[{"value":"OTHER"}]},{"cells":[{"value":"Save"}]},{"cells":[{"value":"Cancel"}]}]}}, { leadsPage }); 
  });

  test('View insights for a lead record', { tag: ['@leads', '@authenticated', '@insightslead'] }, async ({ Given, When, Then, leadsPage }) => { 
    await Given('a lead record has been created for the current test', null, { leadsPage }); 
    await When('the user opens the lead insights panel', null, { leadsPage }); 
    await Then('the lead insights control should be available', null, { leadsPage }); 
  });

  test('Verify the lead record Actions menu', { tag: ['@leads', '@authenticated', '@actionsdropdown'] }, async ({ Given, When, Then, leadsPage }) => { 
    await Given('a lead record has been created for the current test', null, { leadsPage }); 
    await When('the user opens the lead record Actions menu', null, { leadsPage }); 
    await Then('the Actions menu should display the following options:', {"dataTable":{"rows":[{"cells":[{"value":"option"}]},{"cells":[{"value":"Duplicate"}]},{"cells":[{"value":"Delete"}]},{"cells":[{"value":"Convert Lead"}]},{"cells":[{"value":"Print as PDF"}]},{"cells":[{"value":"Find Duplicates"}]},{"cells":[{"value":"View Change Log"}]}]}}, { leadsPage }); 
  });

  test('View the change log for a lead record', { tag: ['@leads', '@authenticated', '@viewchangelog'] }, async ({ Given, When, Then, leadsPage }) => { 
    await Given('a lead record has been created for the current test', null, { leadsPage }); 
    await When('the user selects View Change Log from the Actions menu', null, { leadsPage }); 
    await Then('the lead change log dialog should be displayed', null, { leadsPage }); 
  });

  test('Verify the View Leads list columns and controls', { tag: ['@leads', '@authenticated', '@viewleads'] }, async ({ When, Then, leadsPage }) => { 
    await When('the user opens the View Leads page', null, { leadsPage }); 
    await Then('the View Leads page should display the following elements:', {"dataTable":{"rows":[{"cells":[{"value":"element"}]},{"cells":[{"value":"Name"}]},{"cells":[{"value":"Status"}]},{"cells":[{"value":"Account Name"}]},{"cells":[{"value":"Office Phone"}]},{"cells":[{"value":"Email"}]},{"cells":[{"value":"User"}]},{"cells":[{"value":"Filter"}]}]}}, { leadsPage }); 
  });

  test('Update an existing lead record', { tag: ['@leads', '@authenticated', '@editlead'] }, async ({ Given, When, Then, leadsPage }) => { 
    await Given('a lead record has been created for the current test', null, { leadsPage }); 
    await When('the user edits the lead record and updates its details', null, { leadsPage }); 
    await Then('the updated lead details should be displayed', null, { leadsPage }); 
  });

  test('Filter lead records by last name', { tag: ['@leads', '@authenticated', '@filterbylastname'] }, async ({ Given, When, Then, leadsPage }) => { 
    await Given('the lead list filters are expanded and the configured last name is entered', null, { leadsPage }); 
    await When('the user searches for leads using the last name filter', null, { leadsPage }); 
    await Then('the lead list should contain matching last name results', null, { leadsPage }); 
  });

  test('Select a valid CSV file for lead import', { tag: ['@leads', '@authenticated', '@validfileforimportlead'] }, async ({ When, Then, leadsPage }) => { 
    await When('the user opens the Import Leads page and selects the valid leads CSV file', null, { leadsPage }); 
    await Then('the selected import file name should be displayed', null, { leadsPage }); 
  });

  test('Validate lead import when no file is selected', { tag: ['@leads', '@authenticated', '@invalidfileforimportlead'] }, async ({ When, Then, leadsPage }) => { 
    await When('the user opens the Import Leads page and continues without selecting an import file', null, { leadsPage }); 
    await Then('the import wizard should display the file selection validation state', null, { leadsPage }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/leads.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":8,"tags":["@leads","@authenticated","@leadsdropdown"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"When the user hovers over the Leads navigation menu","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"Then the Leads dropdown should display the following options:","stepMatchArguments":[]}]},
  {"pwTestLine":15,"pickleLine":18,"tags":["@leads","@authenticated","@createlead"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"When the user opens the Create Lead page","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"Then the Create Lead page should display the following elements:","stepMatchArguments":[]}]},
  {"pwTestLine":20,"pickleLine":29,"tags":["@leads","@authenticated","@insightslead"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":30,"keywordType":"Context","textWithKeyword":"Given a lead record has been created for the current test","stepMatchArguments":[]},{"pwStepLine":22,"gherkinStepLine":31,"keywordType":"Action","textWithKeyword":"When the user opens the lead insights panel","stepMatchArguments":[]},{"pwStepLine":23,"gherkinStepLine":32,"keywordType":"Outcome","textWithKeyword":"Then the lead insights control should be available","stepMatchArguments":[]}]},
  {"pwTestLine":26,"pickleLine":35,"tags":["@leads","@authenticated","@actionsdropdown"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":27,"gherkinStepLine":36,"keywordType":"Context","textWithKeyword":"Given a lead record has been created for the current test","stepMatchArguments":[]},{"pwStepLine":28,"gherkinStepLine":37,"keywordType":"Action","textWithKeyword":"When the user opens the lead record Actions menu","stepMatchArguments":[]},{"pwStepLine":29,"gherkinStepLine":38,"keywordType":"Outcome","textWithKeyword":"Then the Actions menu should display the following options:","stepMatchArguments":[]}]},
  {"pwTestLine":32,"pickleLine":48,"tags":["@leads","@authenticated","@viewchangelog"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":33,"gherkinStepLine":49,"keywordType":"Context","textWithKeyword":"Given a lead record has been created for the current test","stepMatchArguments":[]},{"pwStepLine":34,"gherkinStepLine":50,"keywordType":"Action","textWithKeyword":"When the user selects View Change Log from the Actions menu","stepMatchArguments":[]},{"pwStepLine":35,"gherkinStepLine":51,"keywordType":"Outcome","textWithKeyword":"Then the lead change log dialog should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":38,"pickleLine":54,"tags":["@leads","@authenticated","@viewleads"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":39,"gherkinStepLine":55,"keywordType":"Action","textWithKeyword":"When the user opens the View Leads page","stepMatchArguments":[]},{"pwStepLine":40,"gherkinStepLine":56,"keywordType":"Outcome","textWithKeyword":"Then the View Leads page should display the following elements:","stepMatchArguments":[]}]},
  {"pwTestLine":43,"pickleLine":67,"tags":["@leads","@authenticated","@editlead"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":44,"gherkinStepLine":68,"keywordType":"Context","textWithKeyword":"Given a lead record has been created for the current test","stepMatchArguments":[]},{"pwStepLine":45,"gherkinStepLine":69,"keywordType":"Action","textWithKeyword":"When the user edits the lead record and updates its details","stepMatchArguments":[]},{"pwStepLine":46,"gherkinStepLine":70,"keywordType":"Outcome","textWithKeyword":"Then the updated lead details should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":49,"pickleLine":73,"tags":["@leads","@authenticated","@filterbylastname"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":50,"gherkinStepLine":74,"keywordType":"Context","textWithKeyword":"Given the lead list filters are expanded and the configured last name is entered","stepMatchArguments":[]},{"pwStepLine":51,"gherkinStepLine":75,"keywordType":"Action","textWithKeyword":"When the user searches for leads using the last name filter","stepMatchArguments":[]},{"pwStepLine":52,"gherkinStepLine":76,"keywordType":"Outcome","textWithKeyword":"Then the lead list should contain matching last name results","stepMatchArguments":[]}]},
  {"pwTestLine":55,"pickleLine":79,"tags":["@leads","@authenticated","@validfileforimportlead"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":56,"gherkinStepLine":80,"keywordType":"Action","textWithKeyword":"When the user opens the Import Leads page and selects the valid leads CSV file","stepMatchArguments":[]},{"pwStepLine":57,"gherkinStepLine":81,"keywordType":"Outcome","textWithKeyword":"Then the selected import file name should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":60,"pickleLine":84,"tags":["@leads","@authenticated","@invalidfileforimportlead"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":61,"gherkinStepLine":85,"keywordType":"Action","textWithKeyword":"When the user opens the Import Leads page and continues without selecting an import file","stepMatchArguments":[]},{"pwStepLine":62,"gherkinStepLine":86,"keywordType":"Outcome","textWithKeyword":"Then the import wizard should display the file selection validation state","stepMatchArguments":[]}]},
]; // bdd-data-end
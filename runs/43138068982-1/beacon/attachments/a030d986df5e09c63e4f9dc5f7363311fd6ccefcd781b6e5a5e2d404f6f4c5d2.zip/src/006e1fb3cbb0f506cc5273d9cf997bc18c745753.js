// Generated from: features/leads.feature
import { test } from "../../../fixtures.js";

test.describe('Leads Management Module', () => {

  test.beforeEach('Background', async ({ Given, logger, page }, testInfo) => { if (testInfo.error) return;
    await Given('the authenticated user is on the Suite8Demo home page', null, { logger, page }); 
  });
  
  test('Verify Leads module navigation', { tag: ['@leads', '@LeadsNavigation'] }, async ({ When, Then, leadsPage, logger }) => { 
    await When('the user hovers over the Leads module in the top navigation', null, { leadsPage, logger }); 
    await Then('the user should see the Leads dropdown options', {"dataTable":{"rows":[{"cells":[{"value":"Create Lead"}]},{"cells":[{"value":"View Leads"}]},{"cells":[{"value":"Import Leads"}]},{"cells":[{"value":"Create Lead From vCard"}]}]}}, { leadsPage, logger }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/leads.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":8,"tags":["@leads","@LeadsNavigation"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"When the user hovers over the Leads module in the top navigation","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"Then the user should see the Leads dropdown options","stepMatchArguments":[]}]},
]; // bdd-data-end
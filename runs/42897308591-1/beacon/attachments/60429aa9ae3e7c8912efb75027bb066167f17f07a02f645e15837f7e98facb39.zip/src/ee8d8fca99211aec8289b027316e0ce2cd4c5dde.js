// Generated from: features/accounts.feature
import { test } from "../../../fixtures.js";

test.describe('Accounts management', () => {

  test.beforeEach('Background', async ({ Given, logger, page }, testInfo) => { if (testInfo.error) return;
    await Given('the authenticated user is on the Suite8Demo home page', null, { logger, page }); 
  });
  
  test('Verify Accounts module navigation', { tag: ['@accounts', '@AccountsNavigation'] }, async ({ When, Then, accountsPage, logger }) => { 
    await When('the user hovers over the Accounts module in the top navigation', null, { accountsPage, logger }); 
    await Then('the user should see the Accounts dropdown options', {"dataTable":{"rows":[{"cells":[{"value":"Create Account"}]},{"cells":[{"value":"Import Accounts"}]},{"cells":[{"value":"View Accounts"}]}]}}, { accountsPage, logger }); 
  });

  test('Verify Create Account page navigation', { tag: ['@accounts', '@AccountsNavigation'] }, async ({ When, Then, accountsPage, logger }) => { 
    await When('the user clicks on the Accounts module from the top navigation', null, { accountsPage }); 
    await Then('the user should be navigated to the Create Account page', null, { accountsPage, logger }); 
  });

  test('Verify Import Accounts page navigation', { tag: ['@accounts', '@AccountsNavigation'] }, async ({ When, Then, accountsPage, logger }) => { 
    await When('the user clicks on the Import module from the top navigation', null, { accountsPage }); 
    await Then('the user should be navigated to the Import module page', null, { accountsPage, logger }); 
  });

  test('Verify View Accounts page navigation', { tag: ['@accounts', '@AccountsNavigation'] }, async ({ When, Then, accountsPage, logger }) => { 
    await When('the user clicks on the View Accounts module from the top navigation', null, { accountsPage }); 
    await Then('the user should be navigated to the View Accounts module page', null, { accountsPage, logger }); 
  });

  test('Verify required Name field validation on Create Account page', { tag: ['@accounts', '@RequiredNameValidation'] }, async ({ Given, When, Then, accountsPage }) => { 
    await Given('the user is on the Create Account page', null, { accountsPage }); 
    await When('the user clicks Save without entering the required Name field', null, { accountsPage }); 
    await Then('the Name validation message "Missing required field: Name" should be displayed', null, { accountsPage }); 
  });

  test('Create an account with valid mandatory data', { tag: ['@accounts', '@CreateAccountPositive'] }, async ({ Given, When, Then, accountCleanup, accountsPage, logger, page }) => { 
    await Given('the user is on the Create Account page', null, { accountsPage }); 
    await When('the user enters valid account details and clicks Save', null, { accountCleanup, accountsPage, logger, page }); 
    await Then('the user should be navigated to the newly created account detail page', null, { accountsPage, logger, page }); 
  });

  test('Create an account with complete overview information', { tag: ['@accounts', '@CreateAccountCompleteOverview'] }, async ({ Given, When, Then, accountCleanup, accountsPage, logger, page }) => { 
    await Given('the user is on the Create Account page', null, { accountsPage }); 
    await When('the user enters complete overview information from Excel and saves the account', null, { accountCleanup, accountsPage, logger }); 
    await Then('the account should be created with all entered overview information', null, { accountsPage, logger, page }); 
  });

  test('Create an account with a primary email address', { tag: ['@accounts', '@CreateAccountPrimaryEmail'] }, async ({ Given, When, Then, accountCleanup, accountsPage, logger, page }) => { 
    await Given('the user is on the Create Account page', null, { accountsPage }); 
    await When('the user enters a valid account name, email address, selects primary email, and saves the account', null, { accountCleanup, accountsPage, logger }); 
    await Then('the account should be created with the email address marked as primary', null, { accountsPage, logger, page }); 
  });

  test('Validate an invalid email address during account creation', { tag: ['@accounts', '@CreateAccountInvalidEmail'] }, async ({ Given, When, Then, accountsPage, logger }) => { 
    await Given('the user is on the Create Account page', null, { accountsPage }); 
    await When('the user enters a valid account name, an invalid email address, and clicks the Save button', null, { accountsPage, logger }); 
    await Then('the user should see an email-address validation message', null, { accountsPage, logger }); 
  });

  test('Verify Cancel button on Create Account page without entered data', { tag: ['@accounts', '@CancelCreateAccountWithoutData'] }, async ({ Given, When, Then, accountsPage, logger, page }) => { 
    await Given('the user is on the Create Account page', null, { accountsPage }); 
    await When('the user clicks the Cancel button without entering data', null, { accountsPage, logger }); 
    await Then('the user should be navigated back to the Accounts Dashboard page', null, { accountsPage, logger, page }); 
  });

  test('Verify Cancel button on Create Account page with entered data', { tag: ['@accounts', '@CancelCreateAccountWithData'] }, async ({ Given, When, Then, accountsPage, logger }) => { 
    await Given('the user enters account data entered on the Create Account page', null, { accountsPage, logger }); 
    await When('the user clicks the Cancel button', null, { accountsPage, logger }); 
    await Then('the user should see a confirmation popup for unsaved changes', null, { accountsPage, logger }); 
  });

  test('Discard unsaved account data from cancellation popup', { tag: ['@accounts', '@DiscardUnsavedAccountData'] }, async ({ Given, When, Then, accountsPage, logger, page }) => { 
    await Given('the user enters account data entered on the Create Account page', null, { accountsPage, logger }); 
    await When('the user discards the unsaved account data from the cancellation popup', null, { accountsPage, logger }); 
    await Then('the user should be navigated back to the Accounts Dashboard page', null, { accountsPage, logger, page }); 
  });

  test('Continue editing account after dismissing cancellation popup', { tag: ['@accounts', '@ContinueEditingAfterCancel'] }, async ({ Given, When, Then, accountsPage, logger, page }) => { 
    await Given('the user enters account data entered on the Create Account page', null, { accountsPage, logger }); 
    await When('the user dismisses the cancellation popup', null, { accountsPage, logger }); 
    await Then('the user should remain on the Create Account page with entered data retained', null, { accountsPage, logger, page }); 
  });

  test('Search for an existing account by name', { tag: ['@accounts', '@SearchExistingAccountByName'] }, async ({ Given, When, Then, accountCleanup, accountsPage, logger }) => { 
    await Given('an account exists for the account name search \'search_existing_account_by_name\'', null, { accountCleanup, accountsPage, logger }); 
    await When('the user searches for an existing account by name \'search_existing_account_by_name\'', null, { accountsPage, logger }); 
    await Then('the matching account should be displayed for \'search_existing_account_by_name\'', null, { accountsPage, logger }); 
  });

  test('Search for an account using partial account name', { tag: ['@accounts', '@SearchAccountPartialName'] }, async ({ Given, When, Then, accountCleanup, accountsPage, logger }) => { 
    await Given('an account exists for the account name search \'search_account_partial_name\'', null, { accountCleanup, accountsPage, logger }); 
    await When('the user searches with a partial existing account name \'search_account_partial_name\'', null, { accountsPage, logger }); 
    await Then('the matching account should be displayed for \'search_account_partial_name\'', null, { accountsPage, logger }); 
  });

  test('Search for a non-existing account', { tag: ['@accounts', '@SearchNonExistingAccount'] }, async ({ Given, When, Then, accountsPage, logger }) => { 
    await Given('the user is on the View Accounts page', null, { accountsPage, logger }); 
    await When('the user searches for a non-existing account name', null, { accountsPage, logger }); 
    await Then('a no-results message should be displayed', null, { accountsPage, logger }); 
  });

  test('Open an account from the Accounts list', { tag: ['@accounts', '@OpenAccountFromList'] }, async ({ Given, When, Then, accountCleanup, accountListTestData, accountsPage, logger }) => { 
    await Given('an account is available on the View Accounts page', null, { accountCleanup, accountListTestData, accountsPage, logger }); 
    await When('the user selects an account name from the list', null, { accountListTestData, accountsPage, logger }); 
    await Then('the selected account detail page should be displayed', null, { accountListTestData, accountsPage, logger }); 
  });

  test('Verify existing account appears in Recently Viewed', { tag: ['@accounts', '@AccountRecentlyViewed'] }, async ({ Given, When, Then, accountCleanup, accountsPage, logger }) => { 
    await Given('the user has opened an existing account detail page', null, { accountCleanup, accountsPage, logger }); 
    await When('the user opens Recently Viewed from the Accounts module', null, { accountsPage, logger }); 
    await Then('the existing account should be displayed in Recently Viewed', null, { accountsPage, logger }); 
  });

  test('Sort accounts by name', { tag: ['@accounts', '@SortAccountsByName'] }, async ({ Given, When, Then, accountsPage, logger }) => { 
    await Given('the user can see multiple accounts displayed while on view page', null, { accountsPage, logger }); 
    await When('the user sorts the account list by name in ascending order', null, { accountsPage, logger }); 
    await Then('accounts should be displayed in ascending name order', null, { accountsPage }); 
  });

  test('Update account website', { tag: ['@accounts', '@UpdateAccountWebsite'] }, async ({ Given, When, Then, accountCleanup, accountListTestData, accountsPage, logger }) => { 
    await Given('a new account exists for updating its website \'update_account_website\'', null, { accountCleanup, accountListTestData, accountsPage, logger }); 
    await When('the user updates the account website and saves the changes', null, { accountListTestData, accountsPage, logger }); 
    await Then('the account website should be updated successfully', null, { accountListTestData, accountsPage }); 
  });

  test('Update account office phone number', { tag: ['@accounts', '@UpdateAccountOfficePhone'] }, async ({ Given, When, Then, accountCleanup, accountListTestData, accountsPage, logger, page }) => { 
    await Given('a new account exists for updating its office phone number \'update_account_office_phone\'', null, { accountCleanup, accountListTestData, accountsPage, logger }); 
    await When('the user updates the office phone number and saves the changes', null, { accountListTestData, accountsPage, logger }); 
    await Then('the account office phone number should be updated successfully', null, { accountListTestData, accountsPage, page }); 
  });

  test('Cancel changes while editing an account', { tag: ['@accounts', '@CancelAccountEdit'] }, async ({ Given, When, Then, accountCleanup, accountListTestData, accountsPage, logger, page }) => { 
    await Given('the user is editing a newly created account \'cancel_account_edit\'', null, { accountCleanup, accountListTestData, accountsPage, logger }); 
    await When('the user cancels the account changes', null, { accountListTestData, accountsPage, logger }); 
    await Then('the existing account details should remain unchanged', null, { accountListTestData, accountsPage, logger, page }); 
  });

  test('Download the account import template', { tag: ['@accounts', '@ImportAccounts', '@Positive', '@DownloadAccountImportTemplate'] }, async ({ Given, When, Then, accountImportTestData, accountsPage }) => { 
    await Given('the user is on the Import Accounts page', null, { accountsPage }); 
    await When('the user downloads the account import template', null, { accountImportTestData, accountsPage }); 
    await Then('the account import template should be downloaded successfully', null, { accountImportTestData }); 
  });

  test('Select a valid account import file', { tag: ['@accounts', '@ImportAccounts', '@Positive', '@SelectAccountImportFile'] }, async ({ Given, When, Then, accountsPage }) => { 
    await Given('the user is on the Import Accounts page', null, { accountsPage }); 
    await When('the user selects a valid account import file', null, { accountsPage }); 
    await Then('the selected import filename should be displayed', null, { accountsPage }); 
  });

  test('Proceed with a valid account import file', { tag: ['@accounts', '@ImportAccounts', '@Positive', '@ProceedWithValidImportFile'] }, async ({ Given, When, Then, accountsPage, logger }) => { 
    await Given('the user is with a valid account import file selected on the Import Accounts page', null, { accountsPage, logger }); 
    await When('the user clicks Next on the Import Accounts page', null, { accountsPage, logger }); 
    await Then('the next account import configuration step should be displayed', null, { accountsPage, logger }); 
  });

  test('Import new accounts from a valid file', { tag: ['@accounts', '@ImportAccounts', '@Positive', '@ImportNewAccounts'] }, async ({ Given, When, Then, accountImportTestData, accountsPage, logger }) => { 
    await Given('a valid import file containing new account data is available', null, { accountImportTestData, accountsPage, logger }); 
    await When('the user completes the account import using Create new records only', null, { accountImportTestData, accountsPage, logger }); 
    await Then('the imported accounts should contain the values provided in the file', null, { accountImportTestData, accountsPage, logger }); 
  });

  test('Prevent account import without selecting a file', { tag: ['@accounts', '@ImportAccounts', '@Negative', '@ImportWithoutFile'] }, async ({ Given, When, Then, accountsPage, logger }) => { 
    await Given('the user selects Import Accounts page without a file selected', null, { accountsPage, logger }); 
    await When('the user attempts to proceed to the next import step', null, { accountsPage, logger }); 
    await Then('the user should remain on the Upload Import File page without starting an import', null, { accountsPage, logger }); 
  });

  test('Delete an existing account', { tag: ['@accounts', '@DeleteAccount', '@Positive'] }, async ({ Given, When, Then, accountCleanup, accountListTestData, accountsPage, logger, page }) => { 
    await Given('a new account exists for deletion "delete_account"', null, { accountCleanup, accountListTestData, accountsPage, logger, page }); 
    await When('the user deletes the account and confirms the deletion', null, { accountCleanup, accountListTestData, accountsPage, logger }); 
    await Then('the deleted account should no longer appear in search results', null, { accountListTestData, accountsPage, logger, page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/accounts.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":8,"tags":["@accounts","@AccountsNavigation"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"When the user hovers over the Accounts module in the top navigation","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"Then the user should see the Accounts dropdown options","stepMatchArguments":[]}]},
  {"pwTestLine":15,"pickleLine":16,"tags":["@accounts","@AccountsNavigation"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"When the user clicks on the Accounts module from the top navigation","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"Then the user should be navigated to the Create Account page","stepMatchArguments":[]}]},
  {"pwTestLine":20,"pickleLine":21,"tags":["@accounts","@AccountsNavigation"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When the user clicks on the Import module from the top navigation","stepMatchArguments":[]},{"pwStepLine":22,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"Then the user should be navigated to the Import module page","stepMatchArguments":[]}]},
  {"pwTestLine":25,"pickleLine":26,"tags":["@accounts","@AccountsNavigation"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":26,"gherkinStepLine":27,"keywordType":"Action","textWithKeyword":"When the user clicks on the View Accounts module from the top navigation","stepMatchArguments":[]},{"pwStepLine":27,"gherkinStepLine":28,"keywordType":"Outcome","textWithKeyword":"Then the user should be navigated to the View Accounts module page","stepMatchArguments":[]}]},
  {"pwTestLine":30,"pickleLine":31,"tags":["@accounts","@RequiredNameValidation"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":31,"gherkinStepLine":32,"keywordType":"Context","textWithKeyword":"Given the user is on the Create Account page","stepMatchArguments":[]},{"pwStepLine":32,"gherkinStepLine":33,"keywordType":"Action","textWithKeyword":"When the user clicks Save without entering the required Name field","stepMatchArguments":[]},{"pwStepLine":33,"gherkinStepLine":34,"keywordType":"Outcome","textWithKeyword":"Then the Name validation message \"Missing required field: Name\" should be displayed","stepMatchArguments":[{"group":{"start":28,"value":"\"Missing required field: Name\"","children":[{"start":29,"value":"Missing required field: Name","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":36,"pickleLine":37,"tags":["@accounts","@CreateAccountPositive"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":37,"gherkinStepLine":38,"keywordType":"Context","textWithKeyword":"Given the user is on the Create Account page","stepMatchArguments":[]},{"pwStepLine":38,"gherkinStepLine":39,"keywordType":"Action","textWithKeyword":"When the user enters valid account details and clicks Save","stepMatchArguments":[]},{"pwStepLine":39,"gherkinStepLine":40,"keywordType":"Outcome","textWithKeyword":"Then the user should be navigated to the newly created account detail page","stepMatchArguments":[]}]},
  {"pwTestLine":42,"pickleLine":43,"tags":["@accounts","@CreateAccountCompleteOverview"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":43,"gherkinStepLine":44,"keywordType":"Context","textWithKeyword":"Given the user is on the Create Account page","stepMatchArguments":[]},{"pwStepLine":44,"gherkinStepLine":45,"keywordType":"Action","textWithKeyword":"When the user enters complete overview information from Excel and saves the account","stepMatchArguments":[]},{"pwStepLine":45,"gherkinStepLine":46,"keywordType":"Outcome","textWithKeyword":"Then the account should be created with all entered overview information","stepMatchArguments":[]}]},
  {"pwTestLine":48,"pickleLine":51,"tags":["@accounts","@CreateAccountPrimaryEmail"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":49,"gherkinStepLine":52,"keywordType":"Context","textWithKeyword":"Given the user is on the Create Account page","stepMatchArguments":[]},{"pwStepLine":50,"gherkinStepLine":53,"keywordType":"Action","textWithKeyword":"When the user enters a valid account name, email address, selects primary email, and saves the account","stepMatchArguments":[]},{"pwStepLine":51,"gherkinStepLine":54,"keywordType":"Outcome","textWithKeyword":"Then the account should be created with the email address marked as primary","stepMatchArguments":[]}]},
  {"pwTestLine":54,"pickleLine":57,"tags":["@accounts","@CreateAccountInvalidEmail"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":55,"gherkinStepLine":58,"keywordType":"Context","textWithKeyword":"Given the user is on the Create Account page","stepMatchArguments":[]},{"pwStepLine":56,"gherkinStepLine":59,"keywordType":"Action","textWithKeyword":"When the user enters a valid account name, an invalid email address, and clicks the Save button","stepMatchArguments":[]},{"pwStepLine":57,"gherkinStepLine":60,"keywordType":"Outcome","textWithKeyword":"Then the user should see an email-address validation message","stepMatchArguments":[]}]},
  {"pwTestLine":60,"pickleLine":63,"tags":["@accounts","@CancelCreateAccountWithoutData"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":61,"gherkinStepLine":64,"keywordType":"Context","textWithKeyword":"Given the user is on the Create Account page","stepMatchArguments":[]},{"pwStepLine":62,"gherkinStepLine":65,"keywordType":"Action","textWithKeyword":"When the user clicks the Cancel button without entering data","stepMatchArguments":[]},{"pwStepLine":63,"gherkinStepLine":66,"keywordType":"Outcome","textWithKeyword":"Then the user should be navigated back to the Accounts Dashboard page","stepMatchArguments":[]}]},
  {"pwTestLine":66,"pickleLine":69,"tags":["@accounts","@CancelCreateAccountWithData"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":67,"gherkinStepLine":70,"keywordType":"Context","textWithKeyword":"Given the user enters account data entered on the Create Account page","stepMatchArguments":[]},{"pwStepLine":68,"gherkinStepLine":71,"keywordType":"Action","textWithKeyword":"When the user clicks the Cancel button","stepMatchArguments":[]},{"pwStepLine":69,"gherkinStepLine":72,"keywordType":"Outcome","textWithKeyword":"Then the user should see a confirmation popup for unsaved changes","stepMatchArguments":[]}]},
  {"pwTestLine":72,"pickleLine":76,"tags":["@accounts","@DiscardUnsavedAccountData"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":73,"gherkinStepLine":77,"keywordType":"Context","textWithKeyword":"Given the user enters account data entered on the Create Account page","stepMatchArguments":[]},{"pwStepLine":74,"gherkinStepLine":78,"keywordType":"Action","textWithKeyword":"When the user discards the unsaved account data from the cancellation popup","stepMatchArguments":[]},{"pwStepLine":75,"gherkinStepLine":79,"keywordType":"Outcome","textWithKeyword":"Then the user should be navigated back to the Accounts Dashboard page","stepMatchArguments":[]}]},
  {"pwTestLine":78,"pickleLine":83,"tags":["@accounts","@ContinueEditingAfterCancel"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":79,"gherkinStepLine":84,"keywordType":"Context","textWithKeyword":"Given the user enters account data entered on the Create Account page","stepMatchArguments":[]},{"pwStepLine":80,"gherkinStepLine":85,"keywordType":"Action","textWithKeyword":"When the user dismisses the cancellation popup","stepMatchArguments":[]},{"pwStepLine":81,"gherkinStepLine":86,"keywordType":"Outcome","textWithKeyword":"Then the user should remain on the Create Account page with entered data retained","stepMatchArguments":[]}]},
  {"pwTestLine":84,"pickleLine":90,"tags":["@accounts","@SearchExistingAccountByName"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":85,"gherkinStepLine":91,"keywordType":"Context","textWithKeyword":"Given an account exists for the account name search 'search_existing_account_by_name'","stepMatchArguments":[{"group":{"start":46,"value":"'search_existing_account_by_name'","children":[{"children":[{}]},{"start":47,"value":"search_existing_account_by_name","children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":86,"gherkinStepLine":92,"keywordType":"Action","textWithKeyword":"When the user searches for an existing account by name 'search_existing_account_by_name'","stepMatchArguments":[{"group":{"start":50,"value":"'search_existing_account_by_name'","children":[{"children":[{}]},{"start":51,"value":"search_existing_account_by_name","children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":87,"gherkinStepLine":93,"keywordType":"Outcome","textWithKeyword":"Then the matching account should be displayed for 'search_existing_account_by_name'","stepMatchArguments":[{"group":{"start":45,"value":"'search_existing_account_by_name'","children":[{"children":[{}]},{"start":46,"value":"search_existing_account_by_name","children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":90,"pickleLine":97,"tags":["@accounts","@SearchAccountPartialName"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":91,"gherkinStepLine":98,"keywordType":"Context","textWithKeyword":"Given an account exists for the account name search 'search_account_partial_name'","stepMatchArguments":[{"group":{"start":46,"value":"'search_account_partial_name'","children":[{"children":[{}]},{"start":47,"value":"search_account_partial_name","children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":92,"gherkinStepLine":99,"keywordType":"Action","textWithKeyword":"When the user searches with a partial existing account name 'search_account_partial_name'","stepMatchArguments":[{"group":{"start":55,"value":"'search_account_partial_name'","children":[{"children":[{}]},{"start":56,"value":"search_account_partial_name","children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":93,"gherkinStepLine":100,"keywordType":"Outcome","textWithKeyword":"Then the matching account should be displayed for 'search_account_partial_name'","stepMatchArguments":[{"group":{"start":45,"value":"'search_account_partial_name'","children":[{"children":[{}]},{"start":46,"value":"search_account_partial_name","children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":96,"pickleLine":105,"tags":["@accounts","@SearchNonExistingAccount"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":97,"gherkinStepLine":106,"keywordType":"Context","textWithKeyword":"Given the user is on the View Accounts page","stepMatchArguments":[]},{"pwStepLine":98,"gherkinStepLine":107,"keywordType":"Action","textWithKeyword":"When the user searches for a non-existing account name","stepMatchArguments":[]},{"pwStepLine":99,"gherkinStepLine":108,"keywordType":"Outcome","textWithKeyword":"Then a no-results message should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":102,"pickleLine":111,"tags":["@accounts","@OpenAccountFromList"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":103,"gherkinStepLine":112,"keywordType":"Context","textWithKeyword":"Given an account is available on the View Accounts page","stepMatchArguments":[]},{"pwStepLine":104,"gherkinStepLine":113,"keywordType":"Action","textWithKeyword":"When the user selects an account name from the list","stepMatchArguments":[]},{"pwStepLine":105,"gherkinStepLine":114,"keywordType":"Outcome","textWithKeyword":"Then the selected account detail page should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":108,"pickleLine":117,"tags":["@accounts","@AccountRecentlyViewed"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":109,"gherkinStepLine":118,"keywordType":"Context","textWithKeyword":"Given the user has opened an existing account detail page","stepMatchArguments":[]},{"pwStepLine":110,"gherkinStepLine":119,"keywordType":"Action","textWithKeyword":"When the user opens Recently Viewed from the Accounts module","stepMatchArguments":[]},{"pwStepLine":111,"gherkinStepLine":120,"keywordType":"Outcome","textWithKeyword":"Then the existing account should be displayed in Recently Viewed","stepMatchArguments":[]}]},
  {"pwTestLine":114,"pickleLine":124,"tags":["@accounts","@SortAccountsByName"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":115,"gherkinStepLine":125,"keywordType":"Context","textWithKeyword":"Given the user can see multiple accounts displayed while on view page","stepMatchArguments":[]},{"pwStepLine":116,"gherkinStepLine":126,"keywordType":"Action","textWithKeyword":"When the user sorts the account list by name in ascending order","stepMatchArguments":[]},{"pwStepLine":117,"gherkinStepLine":127,"keywordType":"Outcome","textWithKeyword":"Then accounts should be displayed in ascending name order","stepMatchArguments":[]}]},
  {"pwTestLine":120,"pickleLine":130,"tags":["@accounts","@UpdateAccountWebsite"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":121,"gherkinStepLine":131,"keywordType":"Context","textWithKeyword":"Given a new account exists for updating its website 'update_account_website'","stepMatchArguments":[{"group":{"start":46,"value":"'update_account_website'","children":[{"children":[{}]},{"start":47,"value":"update_account_website","children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":122,"gherkinStepLine":132,"keywordType":"Action","textWithKeyword":"When the user updates the account website and saves the changes","stepMatchArguments":[]},{"pwStepLine":123,"gherkinStepLine":133,"keywordType":"Outcome","textWithKeyword":"Then the account website should be updated successfully","stepMatchArguments":[]}]},
  {"pwTestLine":126,"pickleLine":136,"tags":["@accounts","@UpdateAccountOfficePhone"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":127,"gherkinStepLine":137,"keywordType":"Context","textWithKeyword":"Given a new account exists for updating its office phone number 'update_account_office_phone'","stepMatchArguments":[{"group":{"start":58,"value":"'update_account_office_phone'","children":[{"children":[{}]},{"start":59,"value":"update_account_office_phone","children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":128,"gherkinStepLine":138,"keywordType":"Action","textWithKeyword":"When the user updates the office phone number and saves the changes","stepMatchArguments":[]},{"pwStepLine":129,"gherkinStepLine":139,"keywordType":"Outcome","textWithKeyword":"Then the account office phone number should be updated successfully","stepMatchArguments":[]}]},
  {"pwTestLine":132,"pickleLine":143,"tags":["@accounts","@CancelAccountEdit"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":133,"gherkinStepLine":144,"keywordType":"Context","textWithKeyword":"Given the user is editing a newly created account 'cancel_account_edit'","stepMatchArguments":[{"group":{"start":44,"value":"'cancel_account_edit'","children":[{"children":[{}]},{"start":45,"value":"cancel_account_edit","children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":134,"gherkinStepLine":145,"keywordType":"Action","textWithKeyword":"When the user cancels the account changes","stepMatchArguments":[]},{"pwStepLine":135,"gherkinStepLine":146,"keywordType":"Outcome","textWithKeyword":"Then the existing account details should remain unchanged","stepMatchArguments":[]}]},
  {"pwTestLine":138,"pickleLine":149,"tags":["@accounts","@ImportAccounts","@Positive","@DownloadAccountImportTemplate"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":139,"gherkinStepLine":150,"keywordType":"Context","textWithKeyword":"Given the user is on the Import Accounts page","stepMatchArguments":[]},{"pwStepLine":140,"gherkinStepLine":151,"keywordType":"Action","textWithKeyword":"When the user downloads the account import template","stepMatchArguments":[]},{"pwStepLine":141,"gherkinStepLine":152,"keywordType":"Outcome","textWithKeyword":"Then the account import template should be downloaded successfully","stepMatchArguments":[]}]},
  {"pwTestLine":144,"pickleLine":156,"tags":["@accounts","@ImportAccounts","@Positive","@SelectAccountImportFile"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":145,"gherkinStepLine":157,"keywordType":"Context","textWithKeyword":"Given the user is on the Import Accounts page","stepMatchArguments":[]},{"pwStepLine":146,"gherkinStepLine":158,"keywordType":"Action","textWithKeyword":"When the user selects a valid account import file","stepMatchArguments":[]},{"pwStepLine":147,"gherkinStepLine":159,"keywordType":"Outcome","textWithKeyword":"Then the selected import filename should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":150,"pickleLine":162,"tags":["@accounts","@ImportAccounts","@Positive","@ProceedWithValidImportFile"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":151,"gherkinStepLine":163,"keywordType":"Context","textWithKeyword":"Given the user is with a valid account import file selected on the Import Accounts page","stepMatchArguments":[]},{"pwStepLine":152,"gherkinStepLine":164,"keywordType":"Action","textWithKeyword":"When the user clicks Next on the Import Accounts page","stepMatchArguments":[]},{"pwStepLine":153,"gherkinStepLine":165,"keywordType":"Outcome","textWithKeyword":"Then the next account import configuration step should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":156,"pickleLine":168,"tags":["@accounts","@ImportAccounts","@Positive","@ImportNewAccounts"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":157,"gherkinStepLine":169,"keywordType":"Context","textWithKeyword":"Given a valid import file containing new account data is available","stepMatchArguments":[]},{"pwStepLine":158,"gherkinStepLine":170,"keywordType":"Action","textWithKeyword":"When the user completes the account import using Create new records only","stepMatchArguments":[]},{"pwStepLine":159,"gherkinStepLine":171,"keywordType":"Outcome","textWithKeyword":"Then the imported accounts should contain the values provided in the file","stepMatchArguments":[]}]},
  {"pwTestLine":162,"pickleLine":174,"tags":["@accounts","@ImportAccounts","@Negative","@ImportWithoutFile"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":163,"gherkinStepLine":175,"keywordType":"Context","textWithKeyword":"Given the user selects Import Accounts page without a file selected","stepMatchArguments":[]},{"pwStepLine":164,"gherkinStepLine":176,"keywordType":"Action","textWithKeyword":"When the user attempts to proceed to the next import step","stepMatchArguments":[]},{"pwStepLine":165,"gherkinStepLine":177,"keywordType":"Outcome","textWithKeyword":"Then the user should remain on the Upload Import File page without starting an import","stepMatchArguments":[]}]},
  {"pwTestLine":168,"pickleLine":180,"tags":["@accounts","@DeleteAccount","@Positive"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":169,"gherkinStepLine":181,"keywordType":"Context","textWithKeyword":"Given a new account exists for deletion \"delete_account\"","stepMatchArguments":[{"group":{"start":34,"value":"\"delete_account\"","children":[{"start":35,"value":"delete_account","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":170,"gherkinStepLine":182,"keywordType":"Action","textWithKeyword":"When the user deletes the account and confirms the deletion","stepMatchArguments":[]},{"pwStepLine":171,"gherkinStepLine":183,"keywordType":"Outcome","textWithKeyword":"Then the deleted account should no longer appear in search results","stepMatchArguments":[]}]},
]; // bdd-data-end
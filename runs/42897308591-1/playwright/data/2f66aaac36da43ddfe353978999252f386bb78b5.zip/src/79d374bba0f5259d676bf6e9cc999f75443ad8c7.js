// Generated from: features/contacts.feature
import { test } from "../../../fixtures.js";

test.describe('Contacts Management Module', () => {

  test.beforeEach('Background', async ({ Given, logger, page }, testInfo) => { if (testInfo.error) return;
    await Given('the authenticated user is on the Suite8Demo home page', null, { logger, page }); 
  });
  
  test('Verify Contacts module navigation', { tag: ['@contacts', '@ContactsNavigation'] }, async ({ When, Then, contactsPage, logger }) => { 
    await When('the user hovers over the Contacts module in the top navigation', null, { contactsPage, logger }); 
    await Then('the user should see the Contacts dropdown options', {"dataTable":{"rows":[{"cells":[{"value":"Create Contact"}]},{"cells":[{"value":"View Contacts"}]},{"cells":[{"value":"Import Contacts"}]},{"cells":[{"value":"Create Contact From Vcard"}]}]}}, { contactsPage, logger }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/contacts.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":8,"tags":["@contacts","@ContactsNavigation"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the authenticated user is on the Suite8Demo home page","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"When the user hovers over the Contacts module in the top navigation","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"Then the user should see the Contacts dropdown options","stepMatchArguments":[]}]},
]; // bdd-data-end